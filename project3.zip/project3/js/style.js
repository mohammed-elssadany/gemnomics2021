/*global $,alert,console*/

$(document).ready(function(){
    
    'use strict';
    
   var myheader=$('.header');
    
    myheader.height($(window).height());
    
    $(window).resize(function(){
        
       myheader.height($(window).height()); 
        
        
    });
    
    $('.links li a').click(function(){
        
       $(this).parent().addClass('active').siblings().removeClass('active');
        
    });
    
    //start slider 
    
    $('.bxslider').each(function(){
        
       $(this).css('paddingTop',($(window).height()-$('.bxslider li').height())/2); 
        
    });
    
     $('.bxslider').bxSlider({
         
         pager: false,
         speed: 500,
         slidemargin:'300px',
         auto:true
         
         
         
     });
    
    //start services
    
    $('.links li a').click(function(){
        
       $('html,body').animate({
           
           scrollTop: $('#'+$(this).data('value')).offset().top
       },1000) ;
        
        
    });
    
    // start slider 
    
    (function autoslider(){
        
        
        $('.slider .active').each(function(){
            
           if(!$(this).is(':last-child')){
               
               $(this).delay(3000).fadeOut(1000,function(){
                   
                  $(this).removeClass('active').next().addClass('active').fadeIn(); 
                   autoslider();
               });
               
           }
            else{
                
                $(this).delay(3000).fadeOut(1000,function(){
                     $(this).removeClass('active');
                    
                   $('.slider div').eq(0).addClass('active').fadeIn(); 
                    
                    autoslider();
                });
            }
            
            
        });
        
        
        
        
        
        
        
        
    }());
    
    // start shufflee
    
    $('#container').mixItUp();
    
   //nice scroll
    
    $('html').niceScroll({
        
        cursorcolor:'#1abc9c',
        cursorwidth :'10px',
        cursorborder:'1px solid #1abc9c',
        cursorborderradius:'0',
    });
   
    
});